# AL BASHAARIY

Flutter starter app for the AL BASHAARIY bilingual Arabic library.

## Working Poem-page controls
- ❤️ Favorite: toggles the saved state
- 🔗 Share: opens the native device share sheet with a polished AL BASHAARIY message containing:
  - App name
  - Poem title
  - Author
  - Arabic poem
  - English translation
  - Library invitation
- ⬇️ Download: saves the poem and translation locally
- ▶️/⏸️ Audio: real bundled audio playback
- Audio progress slider with current time and duration

The share message is ready to receive an official app/store link once AL BASHAARIY is published.

## Run
1. Install Flutter.
2. Open this folder in Android Studio or VS Code.
3. Run `flutter pub get`.
4. Run `flutter run`.
