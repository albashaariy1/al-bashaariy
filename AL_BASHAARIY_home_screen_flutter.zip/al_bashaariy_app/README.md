# AL BASHAARIY

A Flutter starter app for the AL BASHAARIY bilingual Arabic library.

## Run
1. Install Flutter.
2. Open this folder in Android Studio or VS Code.
3. Run `flutter pub get`.
4. Run `flutter run`.

The first screen is the AL BASHAARIY home screen with:
- Two main sections: AL BASHAARIY and Arabic Library
- Arabic/English language toggle
- Search bar
- Today's Picks
- Categories
- Bottom navigation
