import 'package:flutter/material.dart';

void main() {
  runApp(const AlBashaariyApp());
}

class AlBashaariyApp extends StatelessWidget {
  const AlBashaariyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'AL BASHAARIY',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF7F2E8),
        fontFamily: 'Georgia',
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF123C2C),
          brightness: Brightness.light,
        ),
      ),
      home: const HomeScreen(),
    );
  }
}

const deepGreen = Color(0xFF082A20);
const green = Color(0xFF123C2C);
const gold = Color(0xFFD8A63D);
const cream = Color(0xFFF7F2E8);
const ink = Color(0xFF1D2A24);

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int navIndex = 0;
  bool english = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(child: _hero(context)),
            SliverToBoxAdapter(child: _sectionCards(context)),
            SliverToBoxAdapter(child: _todaysPicks(context)),
            SliverToBoxAdapter(child: _categories(context)),
            const SliverToBoxAdapter(child: SizedBox(height: 24)),
          ],
        ),
      ),
      bottomNavigationBar: _bottomNav(),
    );
  }

  Widget _hero(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 20),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [deepGreen, Color(0xFF0E3B2C)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(28)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              IconButton(
                onPressed: () {},
                icon: const Icon(Icons.menu_rounded, color: gold, size: 30),
              ),
              const Spacer(),
              Column(
                children: const [
                  Text(
                    'البشاري',
                    style: TextStyle(
                      color: gold,
                      fontSize: 30,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Text(
                    'AL BASHAARIY',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      letterSpacing: 2.5,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
              const Spacer(),
              IconButton(
                onPressed: () {},
                icon: const Icon(Icons.notifications_none_rounded,
                    color: gold, size: 28),
              ),
            ],
          ),
          const SizedBox(height: 6),
          const Icon(Icons.auto_stories_rounded, color: gold, size: 34),
          const SizedBox(height: 2),
          Text(
            english ? 'Your Comprehensive Arabic Library' : 'مكتبتك العربية الشاملة',
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white70, fontSize: 14),
          ),
          const SizedBox(height: 16),
          Container(
            height: 52,
            decoration: BoxDecoration(
              color: cream,
              borderRadius: BorderRadius.circular(28),
            ),
            child: TextField(
              decoration: InputDecoration(
                prefixIcon: const Icon(Icons.search_rounded, color: ink),
                hintText: english
                    ? 'Search for a book, poem, story, quote...'
                    : 'ابحث عن كتاب، قصيدة، قصة، اقتباس...',
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(vertical: 15),
                suffixIcon: IconButton(
                  onPressed: () {},
                  icon: const Icon(Icons.tune_rounded, color: green),
                ),
              ),
            ),
          ),
          const SizedBox(height: 10),
          Align(
            alignment: Alignment.centerRight,
            child: TextButton.icon(
              onPressed: () => setState(() => english = !english),
              icon: const Icon(Icons.language_rounded, color: gold, size: 19),
              label: Text(
                english ? 'العربية' : 'English',
                style: const TextStyle(color: Colors.white, fontSize: 13),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionCards(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 18, 14, 4),
      child: Row(
        children: [
          Expanded(
            child: _mainCard(
              titleAr: 'البشاري',
              titleEn: 'AL BASHAARIY',
              subtitle: english ? 'My Content' : 'محتواي الخاص',
              icon: Icons.edit_note_rounded,
              dark: true,
              items: ['Poems', 'Quotes', 'Stories', 'Books'],
              onTap: () {},
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _mainCard(
              titleAr: 'المكتبة العربية',
              titleEn: 'ARABIC LIBRARY',
              subtitle: english ? 'Explore the Library' : 'استكشف المكتبة',
              icon: Icons.menu_book_rounded,
              dark: false,
              items: ['Poems', 'Books', 'Stories', 'Islamic'],
              onTap: () {},
            ),
          ),
        ],
      ),
    );
  }

  Widget _mainCard({
    required String titleAr,
    required String titleEn,
    required String subtitle,
    required IconData icon,
    required bool dark,
    required List<String> items,
    required VoidCallback onTap,
  }) {
    final bg = dark ? deepGreen : const Color(0xFFFFFCF4);
    final fg = dark ? Colors.white : ink;
    final accent = dark ? gold : green;

    return Container(
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: dark ? gold : const Color(0xFFD8C89E)),
        boxShadow: const [
          BoxShadow(blurRadius: 12, offset: Offset(0, 5), color: Color(0x14000000))
        ],
      ),
      child: Column(
        children: [
          Icon(icon, color: accent, size: 38),
          const SizedBox(height: 6),
          Text(titleAr,
              textAlign: TextAlign.center,
              style: TextStyle(color: accent, fontSize: 21, fontWeight: FontWeight.w700)),
          Text(titleEn,
              textAlign: TextAlign.center,
              style: TextStyle(color: fg, fontSize: 11, letterSpacing: 1.2, fontWeight: FontWeight.w700)),
          const SizedBox(height: 5),
          Text(subtitle,
              textAlign: TextAlign.center,
              style: TextStyle(color: dark ? Colors.white70 : ink.withOpacity(.7), fontSize: 12)),
          const SizedBox(height: 10),
          Wrap(
            spacing: 5,
            runSpacing: 5,
            alignment: WrapAlignment.center,
            children: items.map((e) => _miniPill(e, accent, fg)).toList(),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: FilledButton(
              onPressed: onTap,
              style: FilledButton.styleFrom(
                backgroundColor: accent,
                foregroundColor: dark ? deepGreen : Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 10),
              ),
              child: Text(english ? 'Explore' : 'استكشف'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _miniPill(String label, Color accent, Color fg) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5),
      decoration: BoxDecoration(
        border: Border.all(color: accent.withOpacity(.55)),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(label, style: TextStyle(color: fg, fontSize: 9)),
    );
  }

  Widget _todaysPicks(BuildContext context) {
    final picks = [
      ('قصيدة اليوم', 'Poem of the Day', Icons.feather_rounded, 'مَرَرْتُ إِلَى الْعُلَا'),
      ('كتاب اليوم', 'Book of the Day', Icons.menu_book_rounded, 'أدب الدنيا والدين'),
      ('اقتباس اليوم', 'Quote of the Day', Icons.format_quote_rounded, 'العلم يبني بيوتاً...'),
      ('قصة اليوم', 'Story of the Day', Icons.auto_stories_rounded, 'قصة الرجل الصادق'),
    ];

    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 18, 14, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _heading('مختارات اليوم', "Today's Picks"),
          const SizedBox(height: 10),
          SizedBox(
            height: 165,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: picks.length,
              separatorBuilder: (_, __) => const SizedBox(width: 10),
              itemBuilder: (_, i) {
                final p = picks[i];
                return Container(
                  width: 190,
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: i.isEven ? deepGreen : const Color(0xFF314735),
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(p.$3, color: gold, size: 28),
                      const Spacer(),
                      Text(p.$1, style: const TextStyle(color: gold, fontSize: 13)),
                      Text(p.$2, style: const TextStyle(color: Colors.white70, fontSize: 10)),
                      const SizedBox(height: 8),
                      Text(p.$4,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          )),
                      const SizedBox(height: 6),
                      Text(english ? 'Read now  ›' : 'اقرأ الآن  ›',
                          style: const TextStyle(color: gold, fontSize: 11)),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _categories(BuildContext context) {
    final cats = [
      ('قصائد', 'Poems', Icons.feather_rounded),
      ('اقتباسات', 'Quotes', Icons.format_quote_rounded),
      ('قصص', 'Stories', Icons.auto_stories_rounded),
      ('كتب', 'Books', Icons.library_books_rounded),
      ('إسلامية', 'Islamic', Icons.mosque_rounded),
      ('لغة عربية', 'Arabic', Icons.translate_rounded),
      ('أدب', 'Literature', Icons.menu_book_rounded),
      ('تاريخ', 'History', Icons.history_edu_rounded),
      ('تعليمية', 'Education', Icons.school_rounded),
      ('المزيد', 'More', Icons.grid_view_rounded),
    ];

    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 20, 14, 0),
      child: Column(
        children: [
          _heading('التصنيفات', 'Categories'),
          const SizedBox(height: 10),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: cats.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 5,
              crossAxisSpacing: 7,
              mainAxisSpacing: 8,
              childAspectRatio: .78,
            ),
            itemBuilder: (_, i) {
              final c = cats[i];
              return InkWell(
                onTap: () {},
                borderRadius: BorderRadius.circular(14),
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(.65),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: const Color(0xFFE1D3B5)),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(c.$3, color: green, size: 25),
                      const SizedBox(height: 4),
                      Text(c.$1, textAlign: TextAlign.center,
                          style: const TextStyle(color: ink, fontSize: 10, fontWeight: FontWeight.w600)),
                      Text(c.$2, textAlign: TextAlign.center,
                          style: const TextStyle(color: ink, fontSize: 8)),
                    ],
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _heading(String ar, String en) {
    return Row(
      children: [
        Expanded(child: Divider(color: gold.withOpacity(.5))),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Column(
            children: [
              Text(ar, style: const TextStyle(color: ink, fontSize: 18, fontWeight: FontWeight.w700)),
              Text(en, style: const TextStyle(color: ink, fontSize: 10, letterSpacing: .8)),
            ],
          ),
        ),
        Expanded(child: Divider(color: gold.withOpacity(.5))),
      ],
    );
  }

  Widget _bottomNav() {
    final items = [
      (Icons.home_rounded, 'الرئيسية', 'Home'),
      (Icons.search_rounded, 'بحث', 'Search'),
      (Icons.bookmark_rounded, 'المفضلة', 'Favorites'),
      (Icons.download_rounded, 'التنزيلات', 'Downloads'),
      (Icons.person_rounded, 'الحساب', 'Profile'),
    ];

    return NavigationBar(
      selectedIndex: navIndex,
      onDestinationSelected: (i) => setState(() => navIndex = i),
      backgroundColor: deepGreen,
      indicatorColor: gold.withOpacity(.18),
      labelTextStyle: WidgetStatePropertyAll(
        const TextStyle(fontSize: 9, color: Colors.white),
      ),
      destinations: items.map((e) => NavigationDestination(
        icon: Icon(e.$1, color: Colors.white70),
        selectedIcon: Icon(e.$1, color: gold),
        label: english ? e.$3 : e.$2,
      )).toList(),
    );
  }
}
